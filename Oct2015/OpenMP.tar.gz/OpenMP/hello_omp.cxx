// hello world
// basic openmp code to test compiler/environment
// also shows basic thread-scoping of variables
// no command line arguments

#include <iostream>
#include <sstream>

#include <omp.h>

using namespace std;

int main(int argc, char *argv[]) {

  cout << endl;

#pragma omp parallel
  {
    int nt = omp_get_num_threads();
    int tid = omp_get_thread_num();
    stringstream ss;
    ss << "hello from thread ID " << tid << " of " << nt << " threads" << endl;
    cout << ss.str();
  }

  cout << endl;

  int nt,tid;
#pragma omp parallel private(nt,tid)
  {
    nt = omp_get_num_threads();
    tid = omp_get_thread_num();
    stringstream ss;
    ss << "again from thread ID " << tid << " of " << nt << " threads" << endl;
    cout << ss.str();
  }

  cout << endl;

  return 0;
}
