// hello world
// base for first openmp code
// no command line arguments

#include <iostream>
#include <sstream>

using namespace std;

int main(int argc, char *argv[]) {

  stringstream ss;
  ss << "hello world" << endl;
  cout << ss.str();

  return 0;
}
