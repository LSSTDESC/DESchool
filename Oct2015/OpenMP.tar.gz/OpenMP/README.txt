NERSC/edison specific notes.

Make your own copy of this directory, maybe under your home directory to 
avoid filesystem lag.

Grab a 30min interactive debug session on one node of Edison:

% qsub -I -q debug -l mppwidth=24

Edison uses "modules" to control user environments, eg. compilers. Start by
seeing which modules are currently loaded:

% module list

The high level modules for different compilers start with "PrgEnv", and you
can see which ones are available:

% module avail PrgEnv

Before loading a new compiler environment you need to unload your current one:

% module unload PrgEnv-<whatever>

You can control how many threads OpenMP will use by setting the OMP_NUM_THREADS
environment variable with setenv/export in csh/bash.

Notes for various compilers available on Edison:



*Intel*

setup:
% module load PrgEnv-intel

compile without openmp:
% icpc <source> -o <exe>

compile with openmp:
% icpc -openmp <source> -o <exe>



*GNU*

setup:
% module load PrgEnv-gnu

compile without openmp:
% g++ <source> -o <exe>

compile with openmp:
% g++ -fopenmp <source> -o <exe>



*Cray* 
(Note: I have very little experience with this compiler.)

setup:
% module load PrgEnv-cray

compile with openmp (on by default, there's probably a flag to turn off):
% CC <source> -o <exe>



Adrian Pope
apope@anl.gov
2015-10-27
