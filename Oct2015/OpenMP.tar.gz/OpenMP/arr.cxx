// simple example of element-wise math on an array
// takes one command line argument for the length of the array
// I find that 10000000 is a good place to start

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include <sys/time.h>

// return elapsed time in seconds in double precision
// time resolution is likely system-dependent
double timediff(timeval start, timeval stop) {
  int64_t diff = 1000000*(stop.tv_sec - start.tv_sec);
  diff = diff + stop.tv_usec - start.tv_usec;
  return diff/1.0e6;
}

int main(int argc, char *argv[]) {

  timeval start, stop;

  if(argc < 2) {
    fprintf(stderr,"USAGE: %s <n>\n",argv[0]);
    return -1;
  }

  int64_t n = atol(argv[1]);
  double *arr = new double[n];


  gettimeofday(&start,NULL);

  // fill array
  for(uint64_t i=0; i<n; i++)
    arr[i] = i+1.0;

  gettimeofday(&stop,NULL);
  printf("fill arr %e sec\n",timediff(start,stop));



  gettimeofday(&start,NULL);

  // do some math
  for(uint64_t i=0; i<n; i++)
    arr[i] = log(arr[i])*exp(arr[i])/arr[i];

  gettimeofday(&stop,NULL);
  printf("math arr %e sec\n",timediff(start,stop));


  delete arr;

  return 0;
}
